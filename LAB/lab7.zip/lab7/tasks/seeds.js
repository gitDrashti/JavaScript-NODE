const dbConnection = require("../config/mongoConnection");
const uuid = require("node-uuid");

dbConnection().then(db => {
    return db.collection("recipes").drop().then(function(){
        return db;
    }, function(){
        return db;
    }).then((db) => {
        return db.createCollection("recipes");
    }).then(function(recipeCollection){
        var makeDoc = function(title, ingredients, steps){
            return {
                _id: uuid.v4(),
                title: title,
                ingredients: ingredients,
                steps: steps,
                comments: []
            }
        };

        var addComments = function(recipe, poster, comment){
            var newComment = {
                _id: uuid.v4(),
                poster: poster,
                comment: comment
            };

            recipe.comments.push(newComment);
        };

        var listOfRecipes = [];

        var friedEggsIngre = [
            {
                name: "Egg",
                amount: "3 eggs"
            },
            {
                name: "Olive Oil",
                amount: "2 tbsp"
            }
        ];
        var friedEggsSteps = [
            "First, heat a non-stick pan on medium-high until hot",
            "Add the oil to the pan and allow oil to warm; it is ready the oil immediately sizzles upon contact with a drop of water.",
            "Crack the egg and place the egg and yolk in a small prep bowl; do not crack the yolk!",
            "Gently pour the egg from the bowl onto the oil",
            "Wait for egg white to turn bubbly and completely opaque (approx 2 min)",
            "Using a spatula, flip the egg onto its uncooked side until it is completely cooked (approx 2 min)",
            "Remove from oil and plate",
            "Repeat for second egg"
        ];
        var friedEggs = makeDoc("Fried Eggs", friedEggsIngre, friedEggsSteps);
        addComments(friedEggs, "Drashti", "good");
        addComments(friedEggs, "Vandana", "not cooked well");
        addComments(friedEggs, "Mini", "tasty....I just Love it..!");

        var blackForestCakeIngre = [
            {
                name: "Egg",
                amount: "4 eggs"
            },
            {
                name: "Flour",
                amount: "500g"
            },
            {
                name: "Cocoa Powder",
                amount: "800g"
            }
        ];
        var blackForestCakeSteps = [
            "Preheat oven to 350 degrees F. Grease and flour two 9 inch, round, cake pans; cover bottoms with waxed paper.",
            "In a large bowl combine sugar and oil. Blend in vanilla and pumpkin, then beat in eggs one at a time. Gradually beat in flour mixture. Stir in nuts. Spread batter into prepared 12x18 inch pan.",
            "Spoon reserved frosting into pastry bag fitted with star decorator tip. Pipe around top and bottom edges of cake.",
            "Spoon remaining cherry topping onto top of cake.",
        ];
        var blackForestCake = makeDoc("Black Forest Cake", blackForestCakeIngre, blackForestCakeSteps);
        addComments(blackForestCake, "Parth", "amazingly awsome.....! Just like you :)");
        addComments(blackForestCake, "Prashil", "awesome!");

        var friedChickenIngre = [
            {
                name: "chicken",
                amount: "whole chicken"
            },
            {
                name: "buttermilk",
                amount: "1 cup"
            },
            {
                name: "flour",
                amount: "2 cups"
            }
        ];
        var friedChickenSteps = [
            "Take your cut up chicken pieces and skin them if you prefer. Put the flour in a large plastic bag (let the amount of chicken you are cooking dictate the amount of flour you use). Season the flour with paprika, salt and pepper to taste (paprika helps to brown the chicken).",
            "Dip chicken pieces in buttermilk then, a few at a time, put them in the bag with the flour, seal the bag and shake to coat well. Place the coated chicken on a cookie sheet or tray, and cover with a clean dish towel or waxed paper. LET SIT UNTIL THE FLOUR IS OF A PASTE-LIKE CONSISTENCY. THIS IS CRUCIAL!",
            "Fill a large skillet (cast iron is best) about 1/3 to 1/2 full with vegetable oil. Heat until VERY hot. Put in as many chicken pieces as the skillet can hold. Brown the chicken in HOT oil on both sides. When browned, reduce heat and cover skillet; let cook for 30 minutes (the chicken will be cooked through but not crispy). Remove cover, raise heat again and continue to fry until crispy.",
            "Drain the fried chicken on paper towels. Depending on how much chicken you have, you may have to fry in a few shifts. Keep the finished chicken in a slightly warm oven while preparing the rest.",
           ];
        var friedChicken = makeDoc("Crispy Fried Chicken",friedChickenIngre, friedChickenSteps);
        addComments(friedChicken, "Kajal", "Good...");
        addComments(friedChicken, "Me", "Yummy!!");

        listOfRecipes.push(friedEggs, blackForestCake, friedChicken);

        return recipeCollection.insertMany(listOfRecipes).then(function() {
            return recipeCollection.find().toArray();
        }).then(() => {
            console.log("Done seeding database");
            db.close();
        });

    });


});