const mongoCollections = require("../config/mongoCollections");
const recipes = mongoCollections.recipes;
const uuid = require("node-uuid");

let exportedMethods = {
    getCommentsByRecipeId(id){
        if(id == null || id == undefined) throw "Please provide the recipe ID!";
        return recipes().then((recipeCollection) => {
            return recipeCollection.findOne({_id: id}).then((recipe) => {
                if(!recipe) throw "Cannot find the comment!";

                let recipeId = recipe._id;
                let recipeTitle = recipe.title;
                let comments = recipe.comments;

                var rs = [];
                for (i = 0; i < comments.length; i++){
                    let comment = {
                        _id: comments[i]._id,
                        recipeId: recipeId,
                        recipeTitle: recipeTitle,
                        name: comments[i].comment,
                        poster: comments[i].poster
                    };
                    rs.push(comment);
                }
                return rs;
            });
        });
    },
    getCommentsByCommentId(id){
        if(id == null || id == undefined) throw "Please provide the recipe ID!";
        return recipes().then((recipeCollection) => {
            return recipeCollection.findOne({"comments._id": id}).then((recipe) => {
                if(!recipe) throw "Cannot find the comment!";
                let comments = recipe.comments;
                let comment = {
                    _id: id,
                    recipeId: recipe._id,
                    recipeTitle: recipe.title,
                };
                for (i = 0; i < comments.length; i++){
                    if (comments[i]._id == id){
                        comment.name = comments[i].comment;
                        comment.poster = comments[i].poster;
                        break;
                    }
                }
                return comment;
            });
        });
    },
    addComment(id, info){
        if(id == null || id == undefined) throw "Please provide the recipe ID!";
        if(info == null || info == undefined) throw "Cannot find the comment!";
        info._id = uuid.v4();
        return recipes().then((recipeCollection) => {
            return recipeCollection.update({_id: id},  { $push: {"comments": info } }).then((updateInfo) => {
                return this.getCommentsByCommentId(info._id);
            });
        });
    },
    updateComment(id, commentId, commentContent){
        if(id == null || id == undefined) throw "Please provide the recipe ID!";
        if(commentId == null || commentId == undefined) throw "Cannot find the comment!";
        if(commentContent == null || commentContent == undefined) throw "Cannot find the comment!";
        return recipes().then((recipeCollection) => {
            return recipeCollection.update({_id: id, "comments._id": commentId}, { $set: {"comments.$.comment": commentContent}}).then((updateInfo) => {
                return this.getCommentsByCommentId(commentId);
            });
        });
    },
    removeComment(id){
        if(id == null || id == undefined) throw "Cannot find the comment!";
        return recipes().then((recipeCollection) => {
            return recipeCollection.update({}, { $pull: { "comments": { _id: id} } }, { multi: true}).then((deleteInfo) => {

            });
        });
    }
};

module.exports = exportedMethods;