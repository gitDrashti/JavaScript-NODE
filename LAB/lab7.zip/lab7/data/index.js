const recipeRoutes = require("./recipes");
const commentRoutes = require("./comments");

module.exports = {
    recipes: recipeRoutes,
    comments: commentRoutes
};