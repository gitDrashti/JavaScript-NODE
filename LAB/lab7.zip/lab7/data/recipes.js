const mongoCollections = require("../config/mongoCollections");
const recipes = mongoCollections.recipes;
const uuid = require("node-uuid");

let exportedMethods = {
    getAllRecipes(){
        return recipes().then((recipeCollection) => {
            return recipeCollection.find({},{title: 1, _id: 1}).toArray();


        });
    },
    getRecipeById(id){
        if(id == null || id == undefined) throw "You should provide ID!";
        return recipes().then((recipeCollection) => {
            return recipeCollection.findOne({_id: id}).then((recipe) => {
                if (!recipe) throw "Cannot find recipe!";

                return recipe;
            });
        });
    },
    addRecipe(title, ingredients, steps){
        if(title == null || title == undefined) throw "You should provide title!";
        if(ingredients == null || ingredients == undefined) throw "You should provide ingredients!";
        if(steps == null || steps == undefined) throw "You should provide steps!";
        return recipes().then((recipeCollection) => {
            let newRecipe = {
                _id: uuid.v4(),
                title: title,
                ingredients: ingredients,
                steps: steps,
                comments: []
            };

            return recipeCollection.insertOne(newRecipe).then((newInsertInfo) => {
                return newInsertInfo.insertedId;
            }).then((newId) => {
                return this.getRecipeById(newId);
            });
        });
    },
    updateRecipe(id, updatedRecipe){
        if(id == null || id == undefined) throw "You should provide ID!";
        if(updatedRecipe == null || updatedRecipe == undefined) throw "You should provide recipes!";
        return this.getRecipeById(id).then((currentRecipe) => {
            let newRecipe = {};

            if (updatedRecipe.title != null || updatedRecipe.title != undefined) newRecipe.title = updatedRecipe.title;
            if (updatedRecipe.ingredients != null || updatedRecipe.ingredients != undefined) newRecipe.ingredients = updatedRecipe.ingredients;
            if (updatedRecipe.steps != null || updatedRecipe.steps != undefined) newRecipe.steps = updatedRecipe.steps;

            let updateCommand = {
                $set: newRecipe
            };

            return recipes().then((recipeCollection) => {
                return recipeCollection.updateOne({_id: id}, updateCommand).then(() => {
                    return this.getRecipeById(id);
                });
            });
        });
    },
    removeRecipe(id){
        if(id == null || id == undefined) throw "You should provide ID!";
        return recipes().then((recipeCollection) => {
            return recipeCollection.removeOne({_id: id}).then((deletionInfo) => {
                if (deletionInfo.deletedCount === 0){
                    throw (`Could not delete recipe with id of ${id}`)
                }
            });
        });
    }
};

module.exports = exportedMethods;