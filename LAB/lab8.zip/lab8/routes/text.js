// JavaScript source code
//route
const express = require('express');
const router = express.Router();
//const data = require("../data");
//const text = data.text;

router.get("/clientform", (req, res) => {
    res.render("text/clientform", {});
});

router.get("/serverform", (req, res) => {
    res.render("text/serverform", {});
});

router.post("/serverform", (req, res) => {
    let textArea = req.body.textArea;
    let output;

    try {
        output = text.outputString(textArea);
        console.log("No error");

    } catch (e) {
        res.render("text/serverform", { textArea: textArea, error: e });
        return;
    }

    res.render("text/serverform", { textArea: textArea, output: output });
});

module.exports = router;