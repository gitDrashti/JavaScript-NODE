// JavaScript source code
//route
const textRoutes = require("./text");

const constructorMethod = (app) => {
    app.use("/text", textRoutes);

    app.use("*", (req, res) => {
        res.redirect("/text/clientform");
    })

  //  app.use("*", (req, res) => {
    //    let route = path.resolve('static/about.html');
      //  res.sendFile(route);
    //})
};

module.exports = constructorMethod;