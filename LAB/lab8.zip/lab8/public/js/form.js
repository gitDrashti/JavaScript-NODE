// JavaScript source code
(function(){
    let Check_Palindrome = {
        outputString: function (textArea) {

            // Change the string into lower case and remove  all non-alphanumeric characters
            var textarea = textArea.toLowerCase().replace(/[^a-zA-Z0-9]+/g, '');
            //return textarea;
            var cstr = textarea;
            var ccount = 0;
            // Check whether the string is empty or not  
            if (cstr === "") {
                return "Nothing's found! :(  Please input a valid String...";
                //return false;
            }

            //Check whether the entry is string or not
            if (isNaN(textArea) === false) return "No Digits!! String values only! :) ";

            // Check if the length of the string is even or odd   
            if ((cstr.length) % 2 === 0) {
                ccount = (cstr.length) / 2;
            }
            else {
                // If the length of the string is 1 then it becomes a palindrome  
                if (cstr.length === 1) {
                    
                    var list = document.createElement('list');
                    list.innerHTML = textArea + ", ";
                    list.style.color = "blue";
                    document.getElementById("list").appendChild(list)
                    return `'${textArea}' is a palindrome.`;
                    
                    //return true;
                } else {
                    // If the length of the string is odd ignore middle character  
                    ccount = (cstr.length - 1) / 2;
                }
            }

            // Loop through to check the first character to the last character and then move next  
            for (var x = 0; x < ccount; x++) {
                // Compare characters and drop them if they do not match   
                if (cstr[x] != cstr.slice(-1 - x)[0]) {

                    var list = document.createElement('list');
                    list.innerHTML = textArea+", ";
                    list.style.color = "red";
                    document.getElementById("list").appendChild(list)
                    return `'${textArea}' is not a palindrome.`;
                    
                }
            }
            var list = document.createElement('list');
            list.innerHTML = textArea + ", ";
            list.style.color = "blue";
            document.getElementById("list").appendChild(list)
            return `'${textArea}' is a palindrome.`;
        }
            
    };

    var clientform = document.getElementById("client-form");

    if (clientform) {
        var textAreaElement = document.getElementById("textArea");
        var errorContainer = document.getElementById("error-container");
        var errorTextElement = errorContainer.getElementsByClassName("text-goes-here")[0];

        var resultContainer = document.getElementById("result-container");
        var resultTextElement = resultContainer.getElementsByClassName("text-goes-here")[0];

        // We can take advantage of functional scoping; our event listener has access to its outer functional scope
        // This means that these variables are accessible in our callback
        clientform.addEventListener("submit", function (event) {
            event.preventDefault();

            try {
                // hide containers by default
                errorContainer.classList.add("hidden");
                resultContainer.classList.add("hidden");

                // Values come from inputs as strings, no matter what :(
                var textAreaValue = textAreaElement.value;
                var results = Check_Palindrome.outputString(textAreaValue);
                resultTextElement.textContent = results ;
                resultContainer.classList.remove("hidden");
            } catch (e) {
                var message = typeof e === "string" ? e : e.message;
                errorTextElement.textContent = e;
                errorContainer.classList.remove("hidden");
            }
        });
    }

})();
        