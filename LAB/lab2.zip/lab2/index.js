// JavaScript source code
let myModule = require("./printShape");
//console.log(myModule);

console.log(" **********Triangles********** ");
var times = 1;
let triangle;
while (times <= 10) {
    triangle = myModule.triangle(times);
    times++;
}
console.log(" **********Squares********** ");
var times = 2;
while (times <= 11) {
    let squares= myModule.square(times);
    times++;
}
console.log(" **********Rhombus********** ");
var times = 2;
while (times <= 20) {
    let rhombuses;
    if (times % 2 == 0)
        rhombuses= myModule.rhombus(times);
    times++;
}

//myModule.rhombus(0);
//myModule.triangle(0);
//myModule.square(0);

//myModule.rhombus(-1);
//myModule.triangle(-1);
//myModule.square(-1);

//myModule.square();
//myModule.rhombus();
//myModule.triangle();