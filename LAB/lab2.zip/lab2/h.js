// JavaScript source code
function triangle(lines) {

    if (lines < 1 || lines===undefined)
        console.log(`Please Insert Valid Number!! MUST BE ANY POSITIVE NUMBER "< 1"`);
    else if (typeof lines !== "number")
        console.log(`Please check your input. MUST BE ANY POSITIVE NUMBER "< 1"`);

    else {
        console.log(`Input of ${lines}:`);
        let times = 0;
        while (times < 10) {
            var output = " ";
            for (var i = 0; i < lines - 1; i++)
                output += " ";
            var mid_row = "";
            var last_row = "";
            for (var i = 0; i <= lines - 1; i++) {
                //if (lines % 2 == 0) {
                if (i == lines - 1) {
                    while (i <= lines - 1) {
                        for (var j = 0; j < (lines * 2) - 2; j++)
                            last_row += "-";
                        console.log(output + "/" + last_row + "\\");
                        i++;
                    }
                }
                else {
                    console.log(output + "/" + mid_row + "\\");
                    output = output.substring(0, output.length - 1);
                    mid_row += "  ";
                }
            }
            times++;
            console.log("\n");
        }
    }
}

function rhombus (lines) {
    // input validation
    if (lines=== undefined) {               
        throw "Invalid input. Minimum 2 Lines are required! ";
    } else if (lines % 2 != 0 || lines<2) {
        throw "Invalid input. Lines must be even in numbers OR Lines must be valid positive Number > 1";
    } else if (typeof lines !== "number") {                         // datatype validation
        throw "Please check your input. Inputed lines should be any een positive number greater than or equal to 2.";
    } 

    // output processing 
    console.log(`Input of ${lines}:`);

    //let times = 0;
    //while (times <10) {                                           // printing rhombus 10 times
        // printing top bar of square
        var output = "";
        for (var i = 1; i <= (lines-2)/2; i++) 
            output += " ";
        console.log(output + "/" + "-" + "\\");
            
        // printing middle top section of square  
        var mid_row = "";
        for (var i = 1; i <= (lines-2)/2 - 1; i++) 
            mid_row += " ";
        var mid_spaces = "   "
        for (var i = 1; i <= (lines-2)/2; i++) {
            console.log(mid_row + "/" + mid_spaces + "\\");
            mid_row = mid_row.substring(0, mid_row.length - 1);
            mid_spaces += "  ";
        }

        // printing middle bottom section of square 
        for (var i = 0; i < (lines-2)/2; i++) {
            mid_spaces = mid_spaces.substring(0, mid_spaces.length-2);
            console.log(mid_row + "\\" + mid_spaces + "/");
            mid_row += " ";
        }
            
        // printing bottom bar of square
        var output = "";
        for (var i = 1; i <= (lines-2)/2; i++) 
            output += " ";
        console.log(output + "\\" + "-" + "/");

      //  times++;
        console.log("\n");
    //}
        
    //console.log("\n");
}
rhombus(4); rhombus(2);