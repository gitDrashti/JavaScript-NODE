// JavaScript source code

exports.triangle = function (lines) {

    if (lines < 1 || lines === undefined) {
        throw `Please Insert Valid Number!! MUST BE ANY POSITIVE NUMBER "> 1"`;
        console.log(`Please Insert Valid Number!! MUST BE ANY POSITIVE NUMBER "> 1"`);
    }

    else if (typeof lines !== "number") {
        throw `Please check your input. MUST BE ANY POSITIVE NUMBER "> 1"`;
        console.log(`Please check your input. MUST BE ANY POSITIVE NUMBER "> 1"`);
    }
    else {
        console.log(`Input of ${lines}:`);
        //let times = 0;
        //while (times < 10) {
        var output = " ";
        for (var i = 0; i < lines - 1; i++)
            output += " ";
        var mid_row = "";
        var last_row = "";
        for (var i = 0; i <= lines - 1; i++) {
            //if (lines % 2 == 0) {
            if (i == lines - 1) {
                while (i <= lines - 1) {
                    for (var j = 0; j < (lines * 2) - 2; j++)
                        last_row += "-";
                    console.log(output + "/" + last_row + "\\");
                    i++;
                }
            }
            else {
                console.log(output + "/" + mid_row + "\\");
                output = output.substring(0, output.length - 1);
                mid_row += "  ";
            }
        }
        //  times++;
        console.log("\n");
        //}
    }
};

exports.square = function (lines) {
    // console.log(lines);
    if (typeof lines != "number" || lines < 2 || lines < 1 || lines===undefined) {
        throw `Please enter valid number OR minimum 2 lines required!!`;
        console.log("Please enter valid number OR minimum 2 lines required!!");
    }
    else {
        console.log(`Input of ${lines}:`);
        var output = "";
        for (var i = 0; i < lines; i++) {
            output = "|";
            for (var j = 0; j < lines; j++) {
                if (lines == 2) {
                    if (j < lines && j != lines) {
                        while (i <= lines - 1) {
                            output += "-";
                            i++;
                        }
                    }
                }
                else if (lines > 2 && lines % 2 == 0) {
                    if (j < lines && j != lines - 2) {
                        while (j <= lines - 1) {
                            if ((i == 0 && j == 0) || (i == lines - 1 && j == 0)) {
                                for (j = 0; j < lines; j++)
                                    output += "-";
                            }
                            else
                                output += " ";
                            j++;
                        }
                    }
                }
                else {
                    if (j < lines && j != lines - 2) {
                        while (j <= lines - 1) {
                            if ((i == 0 && j == 0) || (i == lines - 1 && j == 0)) {
                                for (j = 0; j < lines; j++)
                                    output += "-";
                            }
                            else
                                output += " ";
                            j++;
                        }
                    }
                }

                var output1 = "|";
                console.log(output + output1);
            }
        } console.log("\n");
    }
};

exports.rhombus = function (lines) {
    // input validation
    if (lines === undefined) {
        throw "Please Insert a Number. Minimum 2 Lines are required! ";
        console.log("Please Insert a Number. Minimum 2 Lines are required! ");
    } else if (lines % 2 != 0 || lines < 2) {
        throw "Invalid input. Lines must be even in numbers OR Lines must be valid positive Number > 1";
        console.log("Invalid input. Lines must be even in numbers OR Lines must be valid positive Number > 1");
    } else if (typeof lines !== "number") {                         // datatype validation
        throw "Please check your input. Inputed lines must be a Positive Number";
        console.log("Please check your input. Inputed lines must be a Positive Number");
    }

    // output processing 
    console.log(`Input of ${lines}:`);

    //let times = 0;
    //while (times <10) {                                           // printing rhombus 10 times
    // printing top bar of square
    var output = "";
    for (var i = 1; i <= (lines - 2) / 2; i++)
        output += " ";
    console.log(output + "/" + "-" + "\\");

    // printing middle top section of square  
    var mid_row = "";
    for (var i = 1; i <= (lines - 2) / 2 - 1; i++)
        mid_row += " ";
    var mid_spaces = "   "
    for (var i = 1; i <= (lines - 2) / 2; i++) {
        console.log(mid_row + "/" + mid_spaces + "\\");
        mid_row = mid_row.substring(0, mid_row.length - 1);
        mid_spaces += "  ";
    }

    // printing middle bottom section of square 
    for (var i = 0; i < (lines - 2) / 2; i++) {
        mid_spaces = mid_spaces.substring(0, mid_spaces.length - 2);
        console.log(mid_row + "\\" + mid_spaces + "/");
        mid_row += " ";
    }

    // printing bottom bar of square
    var output = "";
    for (var i = 1; i <= (lines - 2) / 2; i++)
        output += " ";
    console.log(output + "\\" + "-" + "/");

    //  times++;
    console.log("\n");
    //}

    //console.log("\n");
};

//console.log(exports);