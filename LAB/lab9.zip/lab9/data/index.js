// JavaScript source code

module.exports = {
    user: require("./user")
};