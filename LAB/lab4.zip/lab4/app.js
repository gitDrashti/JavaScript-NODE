// JavaScript source code Drashti Patel
const todo = require("./todo");
const connection = require("./DBConnection");

let addTask = todo.createTask("Ponder Dinosaurs", "Has Anyone Really Been Far Even as Decided to Use Even Go Want to do Look More Like?", false, null);

let newTask = addTask.then((task) => {
    console.log("1. Created the first Task...");
    console.log(task);
    console.log("\n2. New task was added!\n");
    console.log("3. Log all the tasks...")
    console.log(task);
    return todo.createTask("Play Pokemon with Twitch TV", "Should we revive Helix?", task._id);
});

let updatingFirstTask = newTask.then((task1) => {
    console.log(task1);
    return todo.completeTask("Play Pokemon with Twitch TV", "Should we revive Helix?", task1._id);
    
});
let removeTheFirstTask = updatingFirstTask.then((updatedTask) => {
    console.log("\n4. Removed the first Task....Now, the task is:");
    console.log(updatedTask);
    console.log("\n5. Complete the remaining tasks and log them if any else that's all the tasks....");
    return todo.removeTask(updatedTask._id);
});

let otherThingToDo = updatingFirstTask.then((updatedPost) => {
    // ..
});

removeTheFirstTask.catch().then(() => {
    return connection();
}).then((db) => {
    return db.close();
});
