// JavaScript source code Drashti Patel
const todoItems = require("./todoItems");
const todo = todoItems.todo;

let exportedMethods = {
    getAllTasks(tasks) {
        if (!tasks || !Array.isArray(tasks))
            return Promise.reject("You must provide an array of tasks");

        if (tasks.length === 0)
            return Promise.reject("You must provide at least one tasks.");

        return todo().then((todoCollection) => {
            let listTask = {
                tasks: tasks
            };

            return todoCollection
                .insertOne(listTask)
                .then((newList) => {
                    return newList.insertedId;
                })
                .then((newId) => {
                    return this.getTask(newId);
                });
        });
    },
    getTask(id) {
        if (!id)
            return Promise.reject("You must provide an id to search for");

        return todo().then((todoCollection) => {
            return todoCollection.findOne({ _id: id });
        });
    },
    createTask(title, description, completed, completedAt) {
        if (!title)
            return Promise.reject("You must provide a title for the task");
        if (!description)
            return Promise.reject("You must provide a description for the task");
        return todo().then((todoCollection) => {
            let newTask = {
                title: title,
                description: description,
                completed: false,
                completedAt: null
            };

            return todoCollection
                .insertOne(newTask)
                .then((newInsertInformation) => {
                    return newInsertInformation.insertedId;
                })
                .then((newId) => {
                    return this.getTask(newId);
                });
        });
    },
    removeTask(id) {
        if (!id)
            return Promise.reject("You must provide an id to search for");

        return todo().then((todoCollection) => {
            return todoCollection
                .removeOne({ _id: id })
                .then((deletionInfo) => {
                    if (deletionInfo.deletedCount === 0) {
                        throw (`Could not delete task with id of ${id}`)
                    }

                });
        });
    },
    completeTask(title, description, taskId, completed, completedAt) {
        if (!taskId)
            return Promise.reject("You must provide an id to search for");
        if (!title)
            return Promise.reject("You must provide an title to search for");
        if (!description)
            return Promise.reject("You must provide an id to search for");

        return todo().then((todoCollection) => {
            let updatedTask = {
                title: title,
                description: description,
                completed: true,
                completedAt: null
            };

            return todoCollection.updateOne({
                _id: taskId
            }, updatedTask).then(() => {
                return this.getTask(taskId);
            });
        });
    }
}

module.exports = exportedMethods;
