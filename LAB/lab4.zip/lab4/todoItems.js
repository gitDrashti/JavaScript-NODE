// JavaScript source code Drashti Patel
const dbConnection = require("./DBConnection");
//This will allow you to have one refrence to each collection per app
//Feel free to copy and paste this
let getConnectionFn = (collection) => {
    let _col = undefined;
    return () => {
        if (!_col) {
            _col = dbConnection().then(db=> {
                return db.collection(collection);
            });
        }
        return _col;
    }
}

//Now you can list your collections here
module.exports = {
    todo: getConnectionFn("todo")
};
