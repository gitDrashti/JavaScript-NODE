// JavaScript source code Drashti Patel (10411997) LAB 1 
console.log(`Output of function 1:`);
function sumofSquare(num1, num2, num3) {
    if (num1 != undefined || num1=="number" && num2 != undefined|| typeof num2 == "number" && typeof num3 == "number"||num3 != undefined) {
        var result = Math.pow(num1, 2) + Math.pow(num2, 2) + Math.pow(num3, 2)
        console.log(result);
    } else
        console.log(`Invalid Input: Input must be numbers!!`);
}
//test input for function 1
sumofSquare(5, 3, 10);
console.log(`\n`);

//let sumofSquare = (num1, num2, num3) => {
  //  if (typeof num1 == "number" && typeof num2 == "number" && typeof num3 == "number")
    //    return (num1 * num1) + (num2 * num2) + (num3 * num3);
    //else
      //  console.log(`Invalid Input: Must be numbers!!`);
//};
//console.log(sumofSquare(5, 3, 10));

console.log(`Output of function 2:`);
function sayHelloTo(firstName, lastName, title) {
    if (firstName == null) throw "Enter atleast a first name!!";

    else if (lastName == null && typeof firstName == "string") {
        console.log(`Hello, ${firstName}`);
    }
    else if (title == null && typeof firstName == "string" && typeof lastName == "string") {
        console.log(`Hello, ${firstName} ${lastName}. I hope you are having a good day!`);
    }
    else if (typeof firstName == "string" && typeof lastName == "string" && typeof title == "string") {
        console.log(`Hello, ${title} ${firstName} ${lastName}! Have a good evening!`)
    }

    else console.log(`Please enter string value for firstname,lastname,title`);
}
//test input for function 2
//sayHelloTo();
sayHelloTo("Phil");
sayHelloTo("Phil", "Barresi");
sayHelloTo("Phil", "Barresi", "Mr.");
console.log(`\n`);

console.log(`Output of function 3:`);
function cupsOfCoffee(howManyCups) {
    if (typeof howManyCups == "number") {
        for (i = howManyCups; i > 1; i--)
            console.log(`${i} cups of coffee on the desk! ${i} cups of coffee!\nPick one up, drink the cup, ${i - 1} cups of coffee on the desk!\n`);
        console.log(`1 cup of coffee on the desk! 1 cup of coffee!\nPick one up, drink the cup, no more coffee left on the desk!`)
    } else console.log(`Invalid Input: Input must be a number!!`);
};
//test input for function 3
cupsOfCoffee(5);
console.log(`\n`);

console.log(`Output of function 4:`);
function countOccurrencesOfSubstring(fullString, substring) {
    if (typeof fullString == "string" && typeof substring == "string") {
        var atPosition = 0;
        var count = 0;
        while (atPosition !=-1) {
            atPosition = fullString.indexOf(substring, atPosition);
            if (atPosition != -1) {
                count++;
                atPosition++;
            }
        }
        console.log(`The count of "${substring}" in "${fullString}" is ${count}`);
    }
    else
        console.log(`Please enter string value for fullstring and substring`);
};
//test input for function 4
countOccurrencesOfSubstring("Hello world!", "o"); //2
countOccurrencesOfSubstring("Helllllllo, class!", "ll"); //6
console.log(`\n`);

// Period, exclamation and question mark are used as the delimeters to
//separately store the sentences in the array
console.log(`Output of function 5:`);

var paragraph = "Hello, world! I am a paragraph. You can tell that I am a paragraph because there are multiple sentences that are split up by punctuation marks. Grammar can be funny, so I will only put in paragraphs with periods, exclamation marks, and question marks -- no quotations.";

//defining a function to print error messages caused by exceptions
function HelloException(message) {
    console.log(message);
}
function randomizeSentences(paragraph) {
    if(paragraph === undefined || typeof paragraph !== "string"){
        throw new HelloException(`Parameter paragraph is undefined or not a string from function randomizeSentences!!!`);
}
        try {
            //replacing all the delimeters with a common delimeter for splitting
            paragraph = paragraph.replace(/\./g,".|");
            paragraph = paragraph.replace(/\!/g,"!|");
            paragraph = paragraph.replace(/\?/g,"?|");
            var lastPipeIndex = paragraph.lastIndexOf("|");
            paragraph = paragraph.substring(0,lastPipeIndex);

            sentenceArray = paragraph.split('| ');

            //Made use of Durstenfeld shuffle algorithm for shuffling the
            //contents of array.
            for(var i = sentenceArray.length - 1; i > 0; i--){
                var j = Math.floor(Math.random() * (i + 1));
                var temp = sentenceArray[i];
                sentenceArray[i] = sentenceArray[j];
                sentenceArray[j] = temp;
            }

            // forming the new paragraph
            var random_para = "";
            sentenceArray.forEach((value) => {
                random_para += value + " ";
            });

            return random_para;
            //printing the paragraph with randomize sentences
            //console.log(random_para);
        }catch(e){
            console.log(e.message);
        }
    }

    //test input for function 5
console.log(randomizeSentences(paragraph));