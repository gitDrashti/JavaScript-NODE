
const express = require('express');
const router = express.Router();


let obj = 
    {

        "name": "Drashti Patel",
        "biography": ["I was born in San Jose, California on 4 July 1974. I graduated from Air Academy High School in Colorado Springs, CO in June 1992, and from the University of Colorado at Boulder with a Bachelor of Arts in Biochemistry in May 1996. I remained at the University of Colorado to complete her Masters of Science degree in Environmental Engineering in May 1998. After receiving my education, I interned with a lobbyist group on Capitol Hill, supporting drinking water legislation. I later worked as a junior environmental consultant and then project manager in both Washington D.C. and Denver, CO. My clients included the Environmental Protection Agency, Department of Energy, and the U.S. Army. After receiving a direct commission in April 2002, I came on active duty in June 2002. Following Commissioned Officer Training school, I attended the Bioenvironmental Engineering technical school at the School of Aerospace Medicine, Brooks AFB, Texas.",  "In November 2002, I was assigned to the 89th Medical Group, Andrews AFB, Maryland. During My tenure, I served as OIC Industrial Hygiene, OIC Environmental and Readiness Programs, and Flight Operations Officer. I successfully directed AMC's largest environmental program and led a base tiger team for six months after lead was detected in the water at three daycare centers. A key Threat Working Group member, I put plume modeling tools at the crisis action team site and facilitated a DoD team with the installation of $5M NBC detection systems on base. My efforts were key to the squadron earning AMC's Team Aerospace award 2004."],
        "favoriteShows": ["GOT", "TBBT", "WasteWorld", "Friends", "TVD"],
        "hobbies": ["Travelling", "Cooking", "Reading", "Photo editing"]
    }


router.get("", (req, res) => {
   
    res.json(obj);
});
module.exports = router;