
const express = require('express');
const router = express.Router();

var education =[
        {
            "schoolName": "Air Academy High School in Colorado Springs, CO in June 1992",
            "degree": "Bachelor of Arts in Biochemistry in May 1996",
            "favoriteClass": "Biochemistry Part I",
            "favoriteMemory": "Days Celebration in the University...  "
        },
        {
            "schoolName": "University of Colorado",
            "degree": "Masters of Science degree in Environmental Engineering in May 1998",
            "favoriteClass": "Environmental Studies",
            "favoriteMemory": "Graduate Halloween Party in Fall 1997"
        }
    ]
       
router.get("", (req, res) => {
     res.json(education);
});
module.exports = router;