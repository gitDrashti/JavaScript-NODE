const express = require('express');
const router = express.Router();

let story = [
    {

        "storyTitle": "I dated a guy but It won't work out...",
        "story": " I had met an awsome man a year ago. He is really a gentlman. That was a very strange date I have in my life.    Actually my family met him on the social event back in my home country and firstly our families set up a date for us. In the beggining, It was hard to believe that my family has been getting involve in my life. In a first place I wasn't ready to meet him. And the matter was closed. After a month, the guy contacted me directly and introduced himself to me. I was shocked and we started talking...Most like a month and I was about to move forward and he just proposed the other girl. And the funny thing was, that didn't hurt me at all. I am still thinking about it and I haven't had still any answers.  He is still in touch as a friend, But now he has an adorable daughter just like him. Irony is, his wife has just met an accident and now he is all alone again...Life is really so unpredictable...Sometimes it's hard to believe the situations! Firstly I looked at him as a 'would-be-my-life-partner' and now I have nothing but the sympathy for him...... Only change is constant...with the time..."

    }
]

router.get("", (req, res) => {
   
    res.json(story);
});
module.exports = router;

