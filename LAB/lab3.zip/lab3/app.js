// JavaScript source code Drashti Patel

const fileData = require("./fileData");
const textMet = require("./textMetrics");
fs = require('fs');


//Chapter 1
var path = 'D:/Study/CS 546/LAB/lab3/chapter1.result.json';
fs.exists(path, function (exists, error) {
    if (error) {
        reject(error);
    } else {
        if (exists) {
            console.log("yes file exist...reading the file...")
            fs.readFile(path, "utf-8", function (error, data) {
                if (error) {
                    throw error;
                } else {
                    console.log(JSON.parse(data));
                    return data;
                }
            })
        }
        else {
            fileData.getFileAsString("chapter1.txt").then(function (obj) {

                let result1 = textMet.simplify(obj);
                console.log("Result of Chapter 1: \n");
                //console.log(result1);
                return result1;
            }).catch(function (error) {
                console.error("Error parsing the original file\n");
                console.error(error);
                return;
            }).then(function (success) {
                console.log("Printing the chapter1's result into chapter1.debug.txt");
                console.log("\n\n End of code\n");
                return fileData.saveJSONToFile("chapter1.debug.txt", success);
            }).catch(function (error) {
                console.error("Error parsing the original file");
                console.error("Error: " + error)
                return;
            });
            // Writing the json file
            fileData.getFileAsString("chapter1.txt").then(function (obj) {
                let result = textMet.simplify(obj);
                //console.log("Result of Chapter 1: \n");
                console.log(result);
                return result;
            }).catch(function (error) {
                console.error("Error parsing the original file\n");
                console.error(error);
                return;
            }).then(function (chap1) {
                return fileData.getFileAsString("chapter1.txt").then(function (fun2) {

                    let chap1fun2 = textMet.createMetrics(fun2);
                    console.log("Result of function 2: \n");
                    //console.log(chap1fun2);
                    var resultant = [];
                    resultant[0] = chap1;
                    resultant[1] = chap1fun2;
                    console.log(resultant);
                    return resultant;
                });
            }).catch(function (error) {
                console.error("Error parsing the original file\n");
                console.error(error);
                return;
            }).then(function (success) {
                console.log("Printing the chapter1's result into chapter1.result.json");
                console.log("\n\n End of code\n");
                return fileData.saveJSONToFile("chapter1.result.json",success);
            }).catch(function (error) {
                console.error("Error parsing the original file");
                console.error("Error: " + error)
                return;
            })
        }
    }
});
 
//Chapter 2
var path = 'D:/Study/CS 546/LAB/lab3/chapter2.result.json';
fs.exists(path, function (exists, error) {
    if (error) {
        reject(error);
    } else {
        if (exists) {
            console.log("yes file exist...reading the file...")
            fs.readFile(path, "utf-8", function (error, data) {
                if (error) {
                    throw error;//reject(error);
                } else {
                    console.log(JSON.parse(data));
                    return data;
                }
            })
        }
        else {
            fileData.getFileAsString("chapter2.txt").then(function (obj) {

                let result1 = textMet.simplify(obj);
                console.log("Result of Chapter 2: \n");
                //console.log(result1);
                return result1;
            }).catch(function (error) {
                console.error("Error parsing the original file\n");
                console.error(error);
                return;
            }).then(function (success) {
                console.log("Printing the chapter2's result into chapter2.debug.txt");
                console.log("\n\n End of code\n");
                return fileData.saveJSONToFile("chapter2.debug.txt", success);
            }).catch(function (error) {
                console.error("Error parsing the original file");
                console.error("Error: " + error)
                return;
            });
            // Writing the json file
            fileData.getFileAsString("chapter2.txt").then(function (obj) {
                let result = textMet.simplify(obj);
                //console.log("Result of Chapter 2: \n");
                console.log(result);
                return result;
            }).catch(function (error) {
                console.error("Error parsing the original file\n");
                console.error(error);
                return;
            }).then(function (chap1) {
                return fileData.getFileAsString("chapter2.txt").then(function (fun2) {

                    let chap1fun2 = textMet.createMetrics(fun2);
                    //console.log("Result of function 2: \n");
                    //console.log(chap1fun2);
                    var resultant = [];
                    resultant[0] = chap1;
                    resultant[1] = chap1fun2;
                    console.log(resultant);
                    return resultant;
                });
            }).catch(function (error) {
                console.error("Error parsing the original file\n");
                console.error(error);
                return;
            }).then(function (success) {
                console.log("Printing the chapter2's result into chapter2.result.json");
                console.log("\n\n End of code\n");
                return fileData.saveJSONToFile("chapter2.result.json", success);
            }).catch(function (error) {
                console.error("Error parsing the original file");
                console.error("Error: " + error)
                return;
            })
        }
    }
});
//Chapter 3

var path = 'D:/Study/CS 546/LAB/lab3/chapter3.result.json';
fs.exists(path, function (exists, error) {
    if (error) {
        reject(error);
    } else {
        if (exists) {
            console.log("yes file exist...reading the file...")
            fs.readFile(path, "utf-8", function (error, data) {
                if (error) {
                    throw error;//reject(error);
                } else {
                    console.log(JSON.parse(data));
                    return data;
                }
            })
        }
        else {

            fileData.getFileAsString("chapter3.txt").then(function (obj) {

                let result1 = textMet.simplify(obj);
                console.log("Result of Chapter 3: \n");
                //console.log(result1);
                return result1;
            }).catch(function (error) {
                console.error("Error parsing the original file\n");
                console.error(error);
                return;
            }).then(function (success) {
                console.log("Printing the chapter1's result into chapter3.debug.txt");
                console.log("\n\n End of code\n");
                return fileData.saveJSONToFile("chapter3.debug.txt", success);
            }).catch(function (error) {
                console.error("Error parsing the original file");
                console.error("Error: " + error)
                return;
            });

            // Writing the json file
            fileData.getFileAsString("chapter3.txt").then(function (obj) {
                let result = textMet.simplify(obj);
                console.log("Result of Chapter 3: \n");
                //console.log(result);
                return result;
            }).catch(function (error) {
                console.error("Error parsing the original file\n");
                console.error(error);
                return;
            }).then(function (chap1) {
                return fileData.getFileAsString("chapter3.txt").then(function (fun2) {

                    let chap1fun2 = textMet.createMetrics(fun2);
                    console.log("Result of function 2: \n");
                    //console.log(chap1fun2);
                    var resultant = [];
                    resultant[0] = chap1;
                    resultant[1] = chap1fun2;
                    console.log(resultant);
                    return resultant;
                });
            }).catch(function (error) {
                console.error("Error parsing the original file\n");
                console.error(error);
                return;
            }).then(function (success) {
                console.log("Printing the chapter3's result into chapter3.result.json");
                console.log("\n\n End of code\n");
                return fileData.saveJSONToFile("chapter3.result.json", success);
            }).catch(function (error) {
                console.error("Error parsing the original file");
                console.error("Error: " + error)
                return;
            })
        }
    }
});

