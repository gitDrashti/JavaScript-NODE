// JavaScript source code Drashti Patel

const fs = require('fs');
var fileData = exports = module.exports;

fileData.getFileAsString = (path) => {
    return new Promise(function (fulfill, reject) {
        if (!path) {
            reject("No path has been passed to the function");
        } else {
            fs.readFile(path, "utf-8", function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    fulfill(data);
                    //console.log(data.toString());
                }
            });
        }
    });
},

fileData.getFileAsJSON = (path) => {
    return new Promise(function (fulfill, reject) {
        if (!path) {
            reject("No path has been passed to the function");
        } else {
            fs.readFile(path, "utf-8", function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    var json = JSON.parse(data);
                    fulfill(json);
                    //console.log(json);
                }
            });
        }
    });
},

fileData.saveStringToFile = (path, text) => {
    return new Promise(function (fulfill, reject) {
        if (!path) {
            reject("No path has been passed to the function");
        } else {
            fs.writeFile(path, text, function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    fulfill(data);
                    //console.log("String written to file");
                }
            });
        }
    });
}

fileData.saveJSONToFile = (path, json) => {
    return new Promise(function (fulfill, reject) {
        if (!path) {
            reject("No path or obj is provided to the function");
        } else {
            var jsonString = JSON.stringify(json);
            fs.writeFile(path, jsonString, function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    fulfill(jsonString);
                    //console.log("JSON written to file");
                }
            });
        }
    });
}
//getFileAsString("abc.txt");

