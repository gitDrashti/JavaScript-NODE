
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// JavaScript source code DRASHTI PATEL
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
const fs = require('fs');
var textMetrics = exports = module.exports;

//let text = "Hello, my friends! This is a great day to say hello.\n\n\tHello! 2 3 4 23";

//create simplify(text) method

textMetrics.simplify = function (text) {
    if (!text || typeof text !== 'string' || text === undefined) {
        throw "No text passed to the function";
        console.log(`No Text is passed to the function`);
    } else {

        text = text.replace(/\W/g, ' ').toLowerCase();
        text = text.replace(/\s\s+/g, ' ');

        console.log(text +`\n`);
        return text;

    }
}
textMetrics.simplify("Hello, my friends! This is a great day to say hello.\n\n\tHello! 2 3 4 23");

textMetrics.createMetrics = function (text) {
    if (!text || typeof text !== 'string' || text === undefined) {
        throw "No text passed to the function";
        console.log(`No Text is passed to the function`);
    } else {

        let obj = {
            totalLetters: null,
            totalWords: null,
            uniqueWords: null,
            longWords: null,
            averageWordLength: null,
            wordOccurances: {}

        };


        text = text.replace(/\W/g, ' ').toLowerCase();
        text = text.replace(/\s\s+/g, ' ');
        //console.log(text);
        //count of total letters in a line
        let totalLetters = text.replace(/[^a-z0-9]/gi, '').length;
        obj.totalLetters = totalLetters;

        //return obj.totalLetters;

        //count of words in a line
        //console.log(text);
        let countWords = text.replace(/[^a-z0-9]/gi, ' ');
        //console.log(countWords);
        countWords = countWords.trim();
        //console.log(countWords);
        let totalWrds = countWords.split(' ');
        let totalWords = countWords.split(' ').length;
        obj.totalWords = totalWords;
        //console.log(totalWords.length);

        //count of unique words and long words in a line
        let word = {};
        let uniqueWords = 0;
        let longWords = 0;

        for (let i = 0; i < totalWrds.length; ++i) {
            if (!(word.hasOwnProperty(totalWrds[i]))) {
                word[totalWrds[i]] = 1;
                ++uniqueWords;
                if (totalWrds[i].length >= 6)++longWords;
            }
            else ++word[totalWrds[i]];
        }
        obj.uniqueWords = uniqueWords;
        obj.longWords = longWords;

        //average word length in a line
        let averageWordLength = (totalLetters / totalWrds.length * 100) / 100;
        obj.averageWordLength = averageWordLength;
        //console.log(`averageWordLength${obj.averageWordLength}`);

        //count of words repeating in a line
        obj.wordOccurances = word;

        console.log(obj);
        return obj;
        
    }
}
textMetrics.createMetrics("Hello, my friends! This is a great day to say hello.\n\n\tHello! 2 3 4 23");